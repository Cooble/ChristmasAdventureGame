package cs.cooble.item;

import cs.cooble.inventory.item.Item;

/**
 * Created by Matej on 28.7.2017.
 */
public class ItemBigBattery extends Item {
    public ItemBigBattery(int i) {
        super(i);
        setNameAndText("big_battery");
        textureName="item/big_battery_item";
    }
}
