package cs.cooble.location;

import cs.cooble.world.Location;

/**
 * Created by Matej on 9.10.2016.
 */
public class LocationToys extends Location {
    public LocationToys() {
        super("toys");
    }

    @Override
    public void loadTextures() {

    }
}
