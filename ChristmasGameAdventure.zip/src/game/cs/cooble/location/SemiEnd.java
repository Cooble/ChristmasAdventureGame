package cs.cooble.location;

import cs.cooble.world.Location;

/**
 * Created by Matej on 29.7.2017.
 */
public class SemiEnd extends Location {
    public SemiEnd() {
        super("semiend");

    }

    @Override
    public void loadTextures() {

    }

    @Override
    public void onStart() {
        super.onStart();
    }
}
