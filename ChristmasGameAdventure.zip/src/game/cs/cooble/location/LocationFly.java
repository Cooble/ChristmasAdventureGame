package cs.cooble.location;

import cs.cooble.world.Location;

/**
 * Created by Matej on 9.10.2016.
 */
public class LocationFly extends Location {
    public LocationFly() {
        super("fly");
    }

    @Override
    public void loadTextures() {

    }
}
