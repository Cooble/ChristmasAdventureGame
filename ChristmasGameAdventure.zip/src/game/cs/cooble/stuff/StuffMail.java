package cs.cooble.stuff;


import cs.cooble.inventory.stuff.StuffToCome;

/**
 * Created by Matej on 17.12.2015.
 */
public class StuffMail extends StuffToCome {
    public StuffMail() {
        super("mail");
    }

}
