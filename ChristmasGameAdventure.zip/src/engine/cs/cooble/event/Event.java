package cs.cooble.event;

/**
 * Created by Matej on 12.12.2015.
 */
public interface Event {
    void dispatchEvent();
}
