package cs.cooble.window;

/**
 * Created by Matej on 11.12.2015.
 */
public interface Tickable {
    void tick();
}
