package cs.cooble.world;

import java.awt.*;

/**
 * Created by Matej on 17.5.2017.
 */
public interface IRectangle {
    Rectangle getRectangle();
}
