package cs.cooble.world;

/**
 * Created by Matej on 17.5.2017.
 */
public class LocationBlank extends Location {

    public LocationBlank(String id) {
        super(id);
    }

    @Override
    public void loadTextures() {}
}
