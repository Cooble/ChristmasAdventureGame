package cs.cooble.world;


import java.io.Serializable;

/**
 * Created by Matej on 12.12.2015.
 */
public interface IActionRectangle extends Serializable,IRectangle,IAction {

}
