package cs.cooble.graphics;


import org.newdawn.slick.Graphics;

/**
 * Created by Matej on 30.9.2016.
 */
public interface Renderable {
    void render(Graphics graphics);
}
