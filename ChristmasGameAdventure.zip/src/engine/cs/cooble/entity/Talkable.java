package cs.cooble.entity;

/**
 * Created by Matej on 1.1.2016.
 */
public interface Talkable {
    void setIsTalking(boolean isTalking);
}
