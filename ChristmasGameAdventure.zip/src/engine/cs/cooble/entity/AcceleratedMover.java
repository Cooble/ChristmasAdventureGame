package cs.cooble.entity;

/**
 * Used to move IMoveable to another location in Location
 * Needs to call tick()
 *
 * moves moveable with postive and negative acceleration
 */
public final class AcceleratedMover {
    //todo accelerated mover
}
